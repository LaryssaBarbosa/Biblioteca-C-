using System;
using System.Drawing;
using System.Windows.Forms;

namespace biblioteca   
{
    public partial class Form1 : Form
    {
        private const int LINHAS = 15;
        private const int LUGARES = 40;
        private Button[,] poltronas = new Button[LINHAS, LUGARES];
        private Label lblInfo;
        private Button btnFaturamento;

        public Form1()
        {
            InitializeComponent();

            this.Text = "Bilheteria Teatro";
            this.Size = new Size(1600, 800);
            this.StartPosition = FormStartPosition.CenterScreen;

            CriarPoltronas();
            CriarBotaoFaturamento();
        }

        private void CriarPoltronas()
        {
            int tamanho = 25;
            int espacamento = 2;

            for (int i = 0; i < LINHAS; i++)
            {
                for (int j = 0; j < LUGARES; j++)
                {
                    Button btn = new Button();
                    btn.Width = tamanho;
                    btn.Height = tamanho;
                    btn.Left = j * (tamanho + espacamento);
                    btn.Top = i * (tamanho + espacamento);
                    btn.BackColor = Color.LightGreen;
                    btn.Tag = new Tuple<int, int>(i, j);

                    btn.Click += ReservarPoltrona;

                    this.Controls.Add(btn);
                    poltronas[i, j] = btn;
                }
            }
        }

        private void ReservarPoltrona(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (btn.BackColor == Color.LightGreen)
            {
                btn.BackColor = Color.Red;
                MessageBox.Show("Reserva efetuada com sucesso!");
            }
            else
            {
                MessageBox.Show("Esse lugar j� est� ocupado!");
            }
        }

        private void CriarBotaoFaturamento()
        {
            btnFaturamento = new Button();
            btnFaturamento.Text = "Faturamento";
            btnFaturamento.Top = LINHAS * 30;
            btnFaturamento.Left = 10;
            btnFaturamento.Click += BtnFaturamento_Click;

            this.Controls.Add(btnFaturamento);

            lblInfo = new Label();
            lblInfo.AutoSize = true;
            lblInfo.Top = btnFaturamento.Top + 40;
            lblInfo.Left = 10;
            lblInfo.Text = "Informa��es aparecer�o aqui.";
            this.Controls.Add(lblInfo);
        }

        private void BtnFaturamento_Click(object sender, EventArgs e)
        {
            int ocupados = 0;
            double total = 0;

            for (int i = 0; i < LINHAS; i++)
            {
                for (int j = 0; j < LUGARES; j++)
                {
                    if (poltronas[i, j].BackColor == Color.Red)
                    {
                        ocupados++;
                        total += CalcularPreco(i + 1);
                    }
                }
            }

            lblInfo.Text = $"Lugares ocupados: {ocupados}\n" +
                           $"Total da bilheteira: R$ {total:0.00}";
        }

        private double CalcularPreco(int linha)
        {
            if (linha >= 1 && linha <= 5) return 50.0;
            if (linha >= 6 && linha <= 10) return 30.0;
            return 15.0;
        }
    }
}
